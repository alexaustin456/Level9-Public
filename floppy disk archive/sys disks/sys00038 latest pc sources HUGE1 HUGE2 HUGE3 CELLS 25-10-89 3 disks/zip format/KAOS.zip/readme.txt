Welcome to Lancelot from:
 Level 9 Computing,
 PO Box 39,
 Weston-super-Mare
 AVON BS24 9UR
 ENGLAND

If you're stuck, please write, enclosing a self-addressed envelope and a 
stamp (or 4 international reply coupons) for our Lancelot cluesheet.


PC LANCELOT HAS...
 EGA (Enhanced Graphics Adaptor) colour pictures;
 CGA (Colour Graphics Adaptor) colour pictures;
 CGA/Hercules/MGA (Monochrome Graphics Adaptor) black-and-white pictures;
 40- or 80-column text-only display;
 picture compression; 
 picture cache to avoid unnecessary disc loads; 
 edit previous commands, by cursor keys, backspace and DEL;
 SAVE/RESTORE to disc;
 RAM SAVE/RESTORE in memory;
 UNDO (take back moves);


CONTINUOUS DEMONSTRATION. Just before selecting the screen format press 
Alt R. (i.e. type MENU and press return. Hold down 'Alt' and press 'R', 
then press one of 'A' through 'W' then press RETURN.) You can pause the 
demonstration by pressing Alt R again.


COMPATIBILITY. The adventure interpreter on this disc also works with
Knight Orc, Gnome Ranger and Time & Magik. Copy your original and 
replace AINT.EXE, MENU.EXE, MENU.TXT and PALETTE.PIC by the new ones.


HARD DISCS. Lancelot is supplied on floppy disc, but we are pretty 
confident that it should work on other disc drives too. (No promises! 
This is a free extra feature, so it's not a bug if the game won't work 
on your peculiar disc drive.) Just copy the game, file-by-file, into one 
directory.


DISPLAY MODES. Because PCs and PC clones are a varied bunch, Lancelot
presents a menu of twenty three display modes. The following advice 
should help you decide which to use. Please read it from the top:
* If your PC only has the Monochrome Display Adaptor (MDA), use mode (A).
* If you are using a TV and just want 40 column text, use mode (B).
* If your PC has EGA graphics, use the EGA mode (G). EGA colour graphics 
  are not supported by early MSDOS versions.
* If your PC has EGA graphics with a CGA display, use mode (H) or (I).
* If your PC has CGA colour graphics, use mode (D) or (E). 
* If your PC has MGA graphics, or it supports CGA graphics that you want 
  to use for b&w, use the MGA mode (F).
* Otherwise, use mode (C), 80 column text.
* Some EGA modes may not work on less compatible PC clones because they 
  access the graphics board directly. If you have problems, try a 
  'normal', 'slow' or 'very slow' mode instead.


GRAPHICS. Many products only support one of the PC graphic modes; e.g 
providing pictures if your PC has EGA graphics, but otherwise providing 
a text-only game. But Lancelot displays pictures in three major graphic
modes: EGA, CGA and MGA. 

Obviously, there is not enough room on disc for three complete sets of 
graphics, so they are stored as compressed EGA pictures. If a picture 
is displayed in CGA mode, it is expanded to use the bigger CGA pixels, 
and its colours are converted to the CGA palette. If it is displayed in 
MGA mode, the picture's colours are replaced by shaded areas of 
black-and-white. 

When you are using colour CGA graphics, press TAB (the key may look like 
an arrow hitting a wall) to switch between picture and text. When the 
picture is displayed, press cursor keys to slide the visible area around; 
TAB, or any other key, returns to the text. 


COPYRIGHT. Please remember that Level 9 games are protected by copyright 
and take a long time to produce, so only make one copy, for your own use, 
to keep only as long as you have the original game.

Happy Adventuring!
